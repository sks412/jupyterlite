"""Python unit tests for jupyter_ai."""
