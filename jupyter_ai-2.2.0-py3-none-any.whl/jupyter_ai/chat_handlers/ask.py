import asyncio
import json
import os
from typing import Dict, Type
import argparse
import nbformat

from jupyter_ai.models import HumanChatMessage
from jupyter_ai_magics.providers import BaseProvider
from langchain.chains import LLMChain
from langchain.llms import BaseLLM
from langchain.prompts import PromptTemplate

from .base import BaseChatHandler

class GetQueryResponse(LLMChain):
    """Chain to generate a response for code explanation."""

    @classmethod
    def from_llm(cls, llm: BaseLLM, verbose: bool = False) -> LLMChain:

        query_creation_template = (
            "You are an AI and you are coding assistant. You are helping users understand the code in the FOCAL CELL by explaining it.\n"            
            "Here are the requirements for your explaination: \n"
            " Be polite and respectful to the person who wrote the code. Explain the code as clearly as possible\n"
            " If you are not sure about something, don't guess. Keep your response short and to the point \n"
            " Never refer to yourself as AI, you are coding assistant. Never ask the user for the followup \n"
            " Do not include pleasantries at the end of your response.User markdown to format your response where possible. \n"
            " Please explain {code} \n"           
        )
        
        prompt = PromptTemplate(
            template=query_creation_template,
            input_variables=["code"],
        )
        return cls(prompt=prompt, llm=llm, verbose=verbose)

async def generate_outline(query, llm=None, verbose=True):
        """Generate an outline of sections given a description of a notebook."""        
        chain = GetQueryResponse.from_llm(llm=llm, verbose=verbose)
        answer = await chain.apredict(code=query)   
        return answer    


class AskChatHandler(BaseChatHandler):
    """Processes messages prefixed with /ask. This actor will
    send the message as input to a RetrieverQA chain, that
    follows the Retrieval and Generation (RAG) tehnique to
    query the documents from the index, and sends this context
    to the LLM to generate the final reply.
    """

    def __init__(self,  *args, **kwargs):
        super().__init__(*args, **kwargs)

        
        self.parser.prog = "/ask"
        self.parser.add_argument("query", nargs=argparse.REMAINDER)
            
        

    def create_llm_chain(
        self, provider: Type[BaseProvider], provider_params: Dict[str, str]
    ):
        llm = provider(**provider_params)
        self.llm = llm
        return llm
        

    async def _process_message(self, message: HumanChatMessage): 
        
        self.get_llm_chain()
        #prompt = args.query
        prompt = message.body
        

        try:
            # limit chat history to last 2 exchanges
            #self.chat_history = self.chat_history[-2:]

            response = await generate_outline(prompt,self.llm, verbose= True)
            self.reply(response, message)
        except AssertionError as e:
            self.log.error(e)
            response = """Sorry, an error occurred. Please contact admin.
            """
            self.reply(response, message)

    


    
